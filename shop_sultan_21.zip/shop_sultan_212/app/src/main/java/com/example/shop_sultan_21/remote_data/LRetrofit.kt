package com.example.shop_sultan_21.remote_data

object LRetrofit {
    val logging =
}